fs = require('fs');

exports.path = function(ID){
	return 'E:/aaDiscordBot/profiles/' + ID + '.json';
}

function usersPath(ID){
	return 'E:/aaDiscordBot/profiles/' + ID + '.json';
}

exports.createProfile = function(user, userID){
	var profOBJ = {name: user, attack: 1, defense: 1, health: 10, inventory: {amount: 1}};
	var profJSON = JSON.stringify(profOBJ);
	write(usersPath(userID), profJSON);
}

exports.createServerProfile = function(serverID){
	var servProf = {name: serverID, dadjoke: false};
	var servJSON = JSON.stringify(servProf);
	write(usersPath(serverID), servJSON);
}

function write(dest, data){
	fs.writeFile(dest, data, (err) =>{
		if(err){
			console.error(err);
			return;
		};
		console.log("File has been saved.");
	});	
}

exports.write = function (dest, data){
	fs.writeFile(dest, data, (err) =>{
		if(err){
			console.error(err);
			return;
		};
		console.log("File has been saved.");
	});
}

exports.play = async function(msg, name){
	if(msg.member.voice.channelID == null){
		msg.reply("You must be in a voice channel to use this command!");
		return;
	}
	var channel = msg.member.voice.channel;

	const connection = await channel.join();
	const dispatcher = connection.play('./Audio/' + name + '.mp3');
	
	dispatcher.on('finish', () =>{
		console.log('Finished playing!');
		channel.leave();
	});
}

exports.Exists = function (file){
	try {
		if (fs.existsSync(file)) {
			return true;
		}
	} catch(err) {
			console.error(err)
			return false;
	}
}