var auth = require('./auth.json');
var fs = require ('fs');
var Discordjs = require('discord.js');
var client = new Discordjs.Client();
var sloc = require('sloc');
var rpg = require('./rpg.js');

client.commands = new Discordjs.Collection();
client.aliases = new Discordjs.Collection();

fs.readdir("./cmds/", (err, files) => {
	
	var lines = 0;
	
	if(err) console.error(err);
	
	console.log(files);
	
	let jsfiles = files.filter(f => f.split(".").pop() === "js");
	if(jsfiles.length <= 0){
		console.log("No commands to load!");
		return;
	}
	
	console.log(`Loading ${jsfiles.length} commands!`);
	
	jsfiles.forEach((f, i) => {
		let props = require(`./cmds/${f}`);
		try{
			props.help.aliases.forEach(f => {
				client.commands.set(f, props);
			});
		}catch{
			
		}
		console.log(`${i+1}: ${f} loaded!`);
		client.commands.set(props.help.name, props);
	});
});

client.on('ready', () => {

  console.log('Brenden, you are lookin fresh today');
  client.user.setActivity("=help for info", { type: ''})
	.then(presence => console.log('Activity set'))
	.catch(console.error);
});

client.on('message', msg => {
	
	if(msg.channel.id == 717652035390013481){
		msg.embeds.forEach((embed) => {
			var title = embed.title.toLowerCase();		
			if(title.includes('3060') || title.includes('3070')){
				msg.channel.send('<@150432103341752321>');
				msg.channel.send('<@150432103341752321>');
				msg.channel.send('<@150432103341752321>');
			}
			
			if(title.includes('3080') && title.includes('[gpu]')){
				msg.channel.send('<@165653152220184576>');
				msg.channel.send('<@165653152220184576>');
				msg.channel.send('<@165653152220184576>');
			}
			
			if(title.includes('nvme') && title.includes('2tb')){
				msg.channel.send('<@165653152220184576>');
				msg.channel.send('<@165653152220184576>');
				msg.channel.send('<@165653152220184576>');
			}
		});
	}
	
	var args = msg.content.substring(1).split(' ');

	// if(msg.content == "?stfu" && msg.author.id == 481639905747795978){
		// args[0] = "<@481639905747795978>";
		// client.commands.get("move").run(client, msg, args);
	// }

	if (msg.content.substring(0, auth.prefix.length) == auth.prefix) {	

		let cmd = client.commands.get(args[0]);
		
		console.log(cmd);
		args.shift();
		
		if(client.commands.has(cmd)){
			cmd.run(client, msg, args);
		} else{
			client.commands.get(client.aliases.get(args[0]));
			try{
				cmd.run(client, msg, args);
			} catch(err){
				console.log('Command not found.');
			}
		}
    }
	
	
	dadJoke(msg);
	// if(msg.author.id == 132180602773438464){
		// var num = Math.floor(Math.random()*20);
		// if(num > 17){
			// msg.reply(Insult());
		// }
	// }
});

function ping(msg, id){
	msg.channel.send('<@' + id + '>');
}

function ping(msg, id, amt){
	for(var i = 0; i < amt; i++){
		msg.channel.send('<@' + id + '>');
	}
}

async function dadJoke(msg){
	if(!rpg.Exists(rpg.path(msg.channel.guild.id))){
		console.log('attempting to create settings profile for server: ' + msg.channel.guild.id);
		await rpg.createServerProfile(msg.channel.guild.id);
	}
	var servSettings = await require(rpg.path(msg.channel.guild.id));
	if(servSettings.dadjoke == false){
		return;
	}
	if(msg.content.substring(0,3).toLowerCase() == "im "){
		var joke = msg.content;
		var newJoke = "";
		for(var i = 0; i < joke.length; i++){
			if(i < (joke.length - 3)){
				newJoke += joke[i+3];
			}
		}

	}
	else if(msg.content.substring(0,4).toLowerCase() == "i\'m " || msg.content.substring(0, 4).toLowerCase() == "ima "){
		var joke = msg.content;
		var newJoke = "";
		for(var i = 0; i < joke.length; i++){
			if(i < (joke.length - 4)){
				newJoke += joke[i+4];
			}
		}
	} else{
		return;
	}
	if(newJoke.toLowerCase().includes(' im ') || newJoke.toLowerCase().includes(' i\'m' )){
		msg.reply('Nice try idiot');
		return;
	}
	msg.channel.send('Hi ' + newJoke + ', I\'m Chocobot!');
}

function Insult(){
	
	var msg = [
		'You are stinky.',
		'You dummy thickbro',
		'Your nose is the size of an actual boeing 737 commercial airplane.',
		'Shut the frick up, you stinky person.',
		'You just lost ' + Math.floor(Math.random()*10000) + ' points for that one. You\'re going to the bad place pal.',
		'Please stop talking.',
		'You have no friends.',
		'Trash boat',
		'Mouth breather',
		'Troglodyte',
		'Fat loser',
		'Pube chin',
		'Lil Toucan Sam lookin ass',
		'I can smell the poopy turd nuggets in your beard. GO SHAVE NOW!',
		'Don\'t you have some escalator to be falling down?',
		'You stink and you smell bad',
		'F word off, crap idiot.'
	];
		
	var num = Math.floor(Math.random()*msg.length);

	return msg[num];	
}

client.login(auth.token);