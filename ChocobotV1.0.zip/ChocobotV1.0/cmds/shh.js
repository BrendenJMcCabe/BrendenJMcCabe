var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'shh');
}

module.exports.help = {
	name: "shh"
}