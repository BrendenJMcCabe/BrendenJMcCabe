module.exports.run = async(client, msg) =>{
	var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	var key = "";
	
	for(var i = 0; i < 5; i++){
		var num = Math.floor(Math.random() * 36);
		if(num < 26){
			key += alphabet[num];
		} else{
			key += num - 26;
		}
	}
	
	key += "-";
	
	for(var i = 0; i < 5; i++){
		var num = Math.floor(Math.random() * 36);
		if(num < 26){
			key += alphabet[num];
		} else{
			key += num - 26;
		}
	}
	
	key += "-";
	
	for(var i = 0; i < 5; i++){
		var num = Math.floor(Math.random() * 36);
		if(num < 26){
			key += alphabet[num];
		} else{
			key += num - 26;
		}
	}
	msg.reply("Here is your totally legit steam key: " + key);
}


module.exports.help = {
	name: "steamkey"
}