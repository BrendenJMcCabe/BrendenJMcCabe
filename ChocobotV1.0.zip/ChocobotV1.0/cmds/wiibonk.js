var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'wiibonk');
}

module.exports.help = {
	name: "wiibonk",
	aliases: []
}