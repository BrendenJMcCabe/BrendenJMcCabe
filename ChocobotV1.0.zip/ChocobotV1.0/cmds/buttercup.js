var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'buttercup');
}


module.exports.help = {
	name: "buttercup",
	aliases: []
}