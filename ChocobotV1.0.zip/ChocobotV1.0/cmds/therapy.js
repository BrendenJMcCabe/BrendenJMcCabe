module.exports.run = async(client, msg) =>{
	msg.member.voice.channel.join();
	msg.reply('I am here to listen to your problems! Had a bad day? Tell me about it, I\'m all ears! enter =leave when you are ready to end our little therapy session.');
}

module.exports.help = {
	name: "therapy"
}