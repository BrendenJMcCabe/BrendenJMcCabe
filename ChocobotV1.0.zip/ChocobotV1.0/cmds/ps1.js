var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'ps1');
}


module.exports.help = {
	name: "ps1"
}