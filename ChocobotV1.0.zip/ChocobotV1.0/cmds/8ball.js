function Ball(){
	var num = (Math.floor(Math.random() * 10));
	var msg;
	if(num == 1)
		msg = 'it is certain.'
	else if(num == 2)
		msg = 'most likely.'
	else if(num == 3)
		msg = 'Yes'
	else if(num == 4)
		msg = 'Not likely.'
	else if(num == 5)
		msg = 'No.'
	else if(num == 6)
		msg = 'Ask again later.'
	else if(num == 7)
		msg = 'There is a chance.'
	else if(num == 8)
		msg = 'Yeah... maybe... no... unless?'
	else if(num == 9)
		msg = 'Almost certainly not.'
	else
		msg = 'Answer unclear.'
				

	return msg;
}

module.exports.run = async(client, msg, args) =>{
	msg.reply(Ball());
}

module.exports.help = {
	name: "8ball"
}