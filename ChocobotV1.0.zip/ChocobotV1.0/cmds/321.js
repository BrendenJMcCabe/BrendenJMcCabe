var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, '321');
}

module.exports.help = {
	name: "321",
	aliases: ["bebop"]
}