module.exports.run = async(client, msg, args) =>{
	if(args.length == 0){
		msg.reply("you must have a target for this command");
		return;
	}
	
	console.log(args.length);
	
	if(args[0].substring(0, 2) == "<@"){
		args[0] = fixString(args[0]);
	}
	
	if(args.length == 1){
		if(msg.member.voice.channelID == null || msg.guild.member(args[0]).voice.channelID == null){
			msg.reply("You and your target must be in a voice channel.");
			return;
		}
		
		var channel = await msg.guild.member(args[0]).voice.channel;
		var channel2 = await msg.member.voice.channel;
		msg.member.voice.setChannel(channel);
		msg.guild.member(args[0]).voice.setChannel(channel2);
		
	}else if (args.length == 2){
		
		if(args[1].substring(0, 2) == "<@"){
			args[1] = fixString(args[1]);
		}
		
		if(msg.member.voice.channelID == null || msg.guild.member(args[0]).voice.channelID == null){
			msg.reply("Both targets must be in a voice channel.");
			return;
		}
		
		var channel = await msg.guild.member(args[0]).voice.channel;
		var channel2 = await msg.guild.member(args[1]).voice.channel;
		msg.guild.member(args[1]).voice.setChannel(channel);
		msg.guild.member(args[0]).voice.setChannel(channel2);
	}
}

function fixString(value) {
	var oldString = value.toString();
	var newString = "";
	for(var i = 0; i < oldString.length; i++){
		if(oldString[i] >= 0 && oldString[i] <= 9){
			newString += value[i];
		}
	}
	value = newString;
	return value;
}

module.exports.help = {
	name: "swap",
	aliases: []
}