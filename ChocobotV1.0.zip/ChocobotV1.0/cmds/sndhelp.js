const Discord = module.require("discord.js");

function help(){
	var embed = new Discord.MessageEmbed()
		.setTitle("Sound effects")
		.setDescription("A big ole library for sound effects.")
		.addField("321", "Cowboy bebop song", true)
		.addField("barry", "I think this counts as bullying", true)
		.addField("bonk", "coconut bonk sound", true)
		.addField("benthinking", "What ben hears when thinking (Better Off Alone)", true)
		.addField("Eugh", "That weird pufferfish noise.", true)
		.addField("freestyle", "Bo's sick freestyle about Tyler", true)
		.addField("FU", "tyler shouting profanity", true)
		.addField("gamertime", "Dr. pepper :)", true)
		.addField("haha", "Famous fake laughing scene (FFX)", true)
		.addField("me", "Me? Gongaga. (FF7 Crisis Core)", true)
		.addField("meeka", "It was the first thing I found under 'meeka'", true)
		.addField("megabonk", "coconut bonk sound BUT BETTER (LOUD)", true)
		.addField("megabrit", "Austin does his best WW1 British general (LOUD)", true)
		.addField("megabruh", "big boy bruh (LOUD)", true)
		.addField("owie", "Bo says owie", true)
		.addField("piano", "CONSEQUENCES (Key & Peele)", true)
		.addField("ps1", "Hello potion seller", true)
		.addField("ps2", "My potions are too strong for you.", true)
		.addField("redlobster", "Beyonce has a gift for a good lay.", true)
		.addField("run", "RUN. (AWOLNATION)", true)
		.addField("shh", "Bo doesn't want to be in trouble", true)
		.addField("ssj3", "Goku goes Super Saiyan 3 (remix)", true)
		.addField("tyler", "bo gets tyler's attention.", true)
		.addField("ui", "Ultra Instict theme (Dragon Ball Super)", true)
		.addField("whisper", "seductive whispering with a great price.", true)
		.addField("wii", "mii channel theme", true)
		.addField("wiibonk", "I'm sure you can guess", true)
		.addField("yo", "That weird oriental instrumental that you hear in like sumo matches.", true);
//.addField("n", "d", true);
		console.log(embed);
	return embed;
}

module.exports.run = async(client, msg) =>{
	msg.author.send(help());
}

module.exports.help = {
	name: "sndhelp",
	aliases: ["sfxhelp", "soundhelp"]
}