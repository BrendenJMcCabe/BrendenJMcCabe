module.exports.run = async(client, msg, args) =>{
	console.log(args);
	
	if(args[0] == 'help'){
		msg.reply("The syntax of the command is '=roll [range] [number of rolls] ['a'dvantage or 'd'isadvantage]'. The first variable takes any number, the second variable also takes any number, and the third variable takes two characters either 'a' for a roll with advantage or 'd' for a roll with disadvantage. If no number of rolls is defined, only one roll is performed. You can use roll with only one argument (range) or two arguments (range and number of rolls).");
		return;
	}
	
	var num = Math.floor(Math.random() * args[0] + 1);
	
	if(args.length == 1){
		if(num == args[0]){
			msg.reply("Critical roll! you rolled a " + num);
		} else{
			msg.reply("Your roll: " + num);
		}
	} else if (args.length == 2){
		num = MultiRoll(args[0], args[1]);
		if(num == args[0] * args[1]){
			msg.reply("Critical roll! You rolled " + args[1] + "d" + args[0] + " and got: " + num);
		} else{
			msg.reply("You rolled " + args[1] + "d" + args[0] + " and got: " + num);
		}
	} else if (args.length == 3){
			var num1 = MultiRoll(args[0], args[1]);
			var num2 = MultiRoll(args[0], args[1]);
			
			console.log(num1);
			console.log(num2);
			
		if(args[2] == 'a' || args[2] == 'A'){
			num = (num1 > num2)? num1 : num2;
			if(num == args[0] * args[1]){
				msg.reply("Critical roll! You rolled " + args[1] + "d" + args[0] + " with advantage and got: " + num);
			} else{
				msg.reply("You rolled " + args[1] + "d" + args[0] + " with advantage and got: " + num);
			}
		} else if(args[2] == 'd' || args[2] == 'D'){
			num = (num1 < num2)? num1 : num2;
			if(num == args[0] * args[1]){
				msg.reply("Critical roll! You rolled " + args[1] + "d" + args[0] + " with disadvantage and got: " + num);
			} else{
				msg.reply("You rolled " + args[1] + "d" + args[0] + " with disadvantage and got: " + num);
			}
		} else{
			msg.reply("Third argument not recognized. Type '=roll help' for help with this command.");
		}
	}
}

function MultiRoll(range, num){
	var total = 0;
	for(var i = 0; i < num; i++){
		total += Math.floor(Math.random() * range + 1);
	}
	return total;
}

module.exports.help = {
	name: "roll"
}