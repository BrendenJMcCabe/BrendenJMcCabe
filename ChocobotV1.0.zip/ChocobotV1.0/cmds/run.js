var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'run');
}


module.exports.help = {
	name: "run"
}