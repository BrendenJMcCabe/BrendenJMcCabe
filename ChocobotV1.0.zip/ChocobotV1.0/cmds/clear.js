module.exports.run = async(client, msg, args) =>{
	if(!msg.member.hasPermission('MANAGE_MESSAGES')){
		msg.reply("You must have the 'manage messages' permission to use this command.");
		return;
	}
	if(args.length == 0){
		msg.reply("Please specify number of messages to be deleted.");
		return;
	}
	if(args[0] < 0 || args[0] > 99){
		msg.reply("cannot delete " + args[0] + " messages. range is 0-99.");
		return;
	}
	console.log(args[0]);
	var num = parseInt(args[0]) + 1;
	var fetched = await msg.channel.messages.fetch({limit: num});
	msg.channel.bulkDelete(fetched);
}

module.exports.help = {
	name: "clear",
	aliases: ["c", "erase", "delete"]
}