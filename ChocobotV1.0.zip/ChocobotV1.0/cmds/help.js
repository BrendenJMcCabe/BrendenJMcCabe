function help(){
	var helpMsg = ">>> **Hello! Welcome to Brenden's Fun Bot, here is a list of commands:**\n"
	helpMsg += "**ping** : Pong!(tests bot latency)\n"
	helpMsg += "**profile** : various saved stats. Doesn\'t actually do anything yet...\n"
	helpMsg += "**8ball** : ask a question and get an answer\n"
	helpMsg += "**move** : moves Tyler himself\n"
	helpMsg += "**leave** : I leave whatever voicechat I\'m in (helpful for megabruhs)"
	helpMsg += "**\nnumber** : I\'ll give you your daily luck number!"
	helpMsg += "**\nclear** : clear x amount of messages in the current channel (requires 'manage messages' permission)."
	helpMsg += "**\nroll** : use =roll help for help with this command it's kinda a mouthful."
	helpMsg += "**\npig** : Kind of like ping, except I send a special picture to Tyler instead"
	helpMsg += "**\ndecide** : Enter a bunch of choices and I'll give you an answer. IE, Input: A B C\tOutput(randomly): B (spaces seperate choices)"
	helpMsg += "**\ndefine** : I\'ll give you a totally accurate definition of whatever follows!"
	helpMsg += "**\nrandomword** : I\'ll give you a random word/term and define it!"
	helpMsg += "**\nsuggest** : Give me a suggestion! Accepting suggestions for commands, insults, and Tyler quotes"
	helpMsg += "**\nquotet** : I remind the world of a fantastic quote made by Tyler"
	helpMsg += "**\nquoteb** : I remind the world of a fantastic quote made by Bo"
	helpMsg += "\nIf you need help with all sound effect commands, type =sndhelp in your channel (not this direct message chat)."

	
	return helpMsg;
}

module.exports.run = async(client, msg) =>{
	msg.author.send(help());
}

module.exports.help = {
	name: "help"
}