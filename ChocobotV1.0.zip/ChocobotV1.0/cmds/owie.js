var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'owie');
}


module.exports.help = {
	name: "owie"
}