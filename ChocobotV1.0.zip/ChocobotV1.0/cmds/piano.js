var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'piano');
}


module.exports.help = {
	name: "piano"
}