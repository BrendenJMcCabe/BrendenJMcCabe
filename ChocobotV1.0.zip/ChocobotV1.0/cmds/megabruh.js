var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'bruh');
}

module.exports.help = {
	name: "megabruh",
	aliases: ["mb", "bruh"]
}