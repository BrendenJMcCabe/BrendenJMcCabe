module.exports.run = async(client, msg, args) =>{
	if(args.length > 0){
		if(args[0].substring(0, 2) == "<@"){
			var oldString = args[0].toString();
			var newString = "";
			for(var i = 0; i < oldString.length; i++){
				if(oldString[i] >= 0 && oldString[i] <= 9){
					newString += args[0][i];
				}
			}
			args[0] = newString;
			console.log(args[0]);
		}
		var member = await msg.guild.member(args[0]);
		member.voice.setChannel(msg.guild.afkChannel);
		return;
	}

	var channel = msg.guild.member("132180602773438464").voice.channel;
	msg.guild.member("132180602773438464").voice.setChannel(msg.guild.afkChannel);
	
	
	if(msg.author.id == 172154621807165440){
		msg.guild.member("132180602773438464").voice.setChannel(channel);
	}
	

	
}

module.exports.help = {
	name: "move",
	aliases: ["efftylerallmyhomieshatetyler"]
}