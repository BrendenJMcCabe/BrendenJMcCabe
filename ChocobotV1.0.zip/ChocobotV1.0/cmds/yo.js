var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'yo');
}


module.exports.help = {
	name: "yo"
}