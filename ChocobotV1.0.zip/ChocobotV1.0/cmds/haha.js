var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'haha');
}


module.exports.help = {
	name: "haha"
}