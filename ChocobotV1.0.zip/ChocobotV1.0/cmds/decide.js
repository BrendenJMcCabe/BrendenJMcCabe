var Discordjs = require('discord.js');

function decision(args){
	var num = Math.floor(Math.random() * args.length);

	var choice = new String(args[num]);
	if(choice[choice.length-1] == ','){
		choice = choice.substring(0, choice.length - 1);
	}
	return choice;
}

module.exports.run = async(client, msg, args) =>{
	if(args.length > 1){
		msg.reply('hmmm... you should choose... ' + decision(args) + '!');
	} else{
		msg.reply('I didn\'t get enough choices to make a decision. \:(');
	}
}

module.exports.help = {
	name: "decide"
}