var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'ps2');
}


module.exports.help = {
	name: "ps2"
}