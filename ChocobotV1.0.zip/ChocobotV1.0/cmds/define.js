const api = "https://jsonplaceholder.typicode.com/posts";
const snekfetch = require("snekfetch");
const urban = module.require("urban");
const Discord = module.require("discord.js");

module.exports.run = async(client, msg, args) =>{
	if(args.length < 1) return msg.channel.send("Please enter something.");
	var str = args.join(' ');
	
	urban(str).first(json => {
		if(!json) return msg.channel.send("No results found.");
		console.log(json);
		var embed = new Discord.MessageEmbed()
			.setTitle(json.word)
			.setDescription(json.definition)
			.addField("Upvotes", json.thumbs_up, true)
			.addField("Downvotes", json.thumbs_down, true)
			.addField("Example", json.example, true)
			.setFooter(`Author: ${json.author}`);
		
		msg.reply(embed);
	});
	
}

function getPost(json){
	
}

module.exports.help = {
	name: "define"
}