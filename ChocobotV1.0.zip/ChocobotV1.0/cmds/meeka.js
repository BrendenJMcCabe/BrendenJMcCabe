var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'meeka');
}


module.exports.help = {
	name: "meeka",
	aliases: []
}