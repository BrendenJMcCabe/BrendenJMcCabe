var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'summoner');
}

module.exports.help = {
	name: "summoner",
	aliases: ["stayaway"]
}