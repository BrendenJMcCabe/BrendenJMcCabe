var fs = require ('fs');
var rpg = require ('../rpg');
var Discord = module.require('discord.js');

module.exports.run = async(client, msg) =>{
	var servSettings = await require(rpg.path(msg.channel.guild.id));
	
	
	servSettings.dadjoke = !servSettings.dadjoke;
	var servJSON = JSON.stringify(servSettings);
	await rpg.write(rpg.path(servSettings.name), servJSON);
	
	if(servSettings.dadjoke == false){
		msg.channel.send('>>> Dad jokes have been disabled.');
	} else{
		msg.channel.send('>>> Dad jokes have been enabled.');
	}

}

module.exports.help = {
	name: "toggledadjoke",
	aliases: ["tdj"]
}