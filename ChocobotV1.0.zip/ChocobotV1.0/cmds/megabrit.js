var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'megabrit');
}

module.exports.help = {
	name: "megabrit"
}