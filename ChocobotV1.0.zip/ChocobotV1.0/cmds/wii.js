var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'wii');
}


module.exports.help = {
	name: "wii",
	aliases: []
}