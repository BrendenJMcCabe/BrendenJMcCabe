var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'long');
}


module.exports.help = {
	name: "long"
}