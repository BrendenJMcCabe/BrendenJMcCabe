var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'bonk');
}

module.exports.help = {
	name: "bonk",
	aliases: ["coconut"]
}