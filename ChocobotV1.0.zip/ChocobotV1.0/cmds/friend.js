var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'friend');
}

module.exports.help = {
	name: "friend",
	aliases: ["friendinme"]
}