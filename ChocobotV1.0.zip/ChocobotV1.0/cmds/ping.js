

module.exports.run = async(client, msg) =>{
	msg.reply("Pong!");
}

module.exports.help = {
	name: "ping"
}