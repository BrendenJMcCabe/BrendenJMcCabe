
module.exports.run = async(client, msg) =>{
	msg.channel.send("!skip");
}

module.exports.help = {
	name: "skip"
}