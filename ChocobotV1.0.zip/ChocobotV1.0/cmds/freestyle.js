var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'freestyle');
}


module.exports.help = {
	name: "freestyle",
	aliases: ["borap"]
}