const api = "https://jsonplaceholder.typicode.com/posts";
const snekfetch = require("snekfetch");
const urban = module.require("urban");
const Discord = module.require("discord.js");

module.exports.run = async(client, msg, args) =>{
	urban.random().first(json => {
		if(!json) return message.channel.send("No results found.");
		var embed = new Discord.MessageEmbed()
			.setTitle(json.word)
			.setDescription(json.definition)
			.addField("Upvotes", json.thumbs_up, true)
			.addField("Downvotes", json.thumbs_down, true)
			.addField("Example", json.example, true)
			.setFooter(`Author: ${json.author}`);
			
		msg.reply(embed);
	});
}

function getPost(json){
	
}

module.exports.help = {
	name: "randomword"
}