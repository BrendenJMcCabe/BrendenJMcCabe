module.exports.run = async(client, msg) =>{
	msg.member.voice.channel.leave();
}

module.exports.help = {
	name: "leave",
	aliases: ["l"]
}