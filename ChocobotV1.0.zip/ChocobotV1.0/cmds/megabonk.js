var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'megabonk');
}

module.exports.help = {
	name: "megabonk"
}