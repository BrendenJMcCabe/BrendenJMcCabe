var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'scatbonk');
}

module.exports.help = {
	name: "scatbonk", 
	aliases: ["scatbonkman"]
}