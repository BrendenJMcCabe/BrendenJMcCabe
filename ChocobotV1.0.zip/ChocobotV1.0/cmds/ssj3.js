var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'ssj3');
}


module.exports.help = {
	name: "ssj3"
}