var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'me');
}

module.exports.help = {
	name: "me"
}