var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'yoda');
}

module.exports.help = {
	name: "yoda",
	aliases: ["yodadeath, blergh"]
}