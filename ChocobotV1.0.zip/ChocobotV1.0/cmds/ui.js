var player = require('../rpg')

module.exports.run = async(client, msg) =>{
	player.play(msg, 'ui');
}


module.exports.help = {
	name: "ui"
}